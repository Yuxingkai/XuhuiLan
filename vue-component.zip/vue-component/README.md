


1. 属性
  Form
    model 
    rules

  FormItem
    label 文本
    props 数据校验规则key
2. 事件




3. 扩展 (插槽)


子元素想修改父元素传递的属性，不能直接修改
要调用 this.$emit('input',value) 
支持v-model 其实就是绑定value 和@input






1. Form 负责设置规则
2. FormItem 负责校验和显示错误信息
3. Input  负责双向绑定数据 （通知）


form 
  foritem
    input
1. k-input实现v-model 
   1. 其实就是v-model是一个特殊的属性，相当于绑定了:value和@input俩事件
      <custom-input
          v-model="searchText"
      ></custom-input>

      <custom-input
        :value="searchText"
        @input="searchText = $event"
      ></custom-input>
    props传递进来后 不能修改、
2， k-form-item 负责具体校验
  1. 获取当前输入框的规则
  2. 获取输入框的值 对rule规则进行匹配 过滤不是自己的输入事件
  3. 如果输入值和rule不匹配 显示错误信息
3. form
   1. 校验所有的输入框，获取总的校验状态
   2. form里要存储或者是获取formitem的实例