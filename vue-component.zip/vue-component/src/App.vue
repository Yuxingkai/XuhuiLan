<template>
 <div>
   <!-- 校验规则 -->
   <k-form :model="form" :rules="rules">
     <k-form-item label="用户名" prop="name">
       <k-input v-model="form.name" name='name'></k-input>
     </k-form-item>
     <k-form-item label="年龄" prop="age">
       <k-input v-model="form.age" name='age'></k-input>
     </k-form-item>

   </k-form>
     


 </div>
</template>

<script>
import KForm from './components/Form'
import KInput from './components/Input'
import KFormItem from './components/FormItem'
export default{
  name:'app',
  components:{KForm,KFormItem,KInput},
  provide:{
    name:"开课吧"
  },
  data(){
    return{
      form:{
        name:'',
        age:""
      },
      rules:{
        name:[
          {required:true,message:"用户名不能为空"},
          {minLength:3,message:"用户名长度要大于3"},
          {maxLength:10,message:"用户名长度要小于10"},
          ],
        age:{required:true,message:"年龄不能为空"}
      }
    }
  }
}
</script>

<style>

</style>
