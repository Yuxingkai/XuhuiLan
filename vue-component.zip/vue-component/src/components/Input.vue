<template>
<!-- 支持v-model -->
  <input 
  type="text"
    :value="inputValue"
    @input="handleInput"
    @blur="handleBlur"
  />


</template>

<script>
export default {
  
  name:"kInput",
  props:{
    value:{
      type:String,
      default:'',
      required:true
    },
    name:{
      type:String
    }
  },

  data(){
    return {
      inputValue:this.value
    }
  },
  methods:{
    handleInput(e){
      console.log(e)
      const value = e.target.value
      this.inputValue = value
      // 通知父元素修改props
      this.$emit('input',value)
      this.$bus.$emit('kFormItem',{
        value,
        name:this.name})

    },
    handleBlur(){
      const value = this.inputValue
      this.$bus.$emit('kFormItem',{
        value,
        name:this.name
      })
    }
  },
  created(){
    // this.value = 'xx'
  }
}
</script>

<style>

</style>

