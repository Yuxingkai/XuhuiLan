<template>
  <form>
    <slot></slot>
    <!-- <hr>
    <button>点击</button>
    <hr>
    <slot name='slot2'>插槽2</slot> -->
  </form>
</template>

<script>
export default{
  provide(){
    return {
      form:this
    }
  },
  name:'form',
  props:{
    model:{
      type:Object
      },
    rules:{type:Object},
  }
  // props:['name']
}
</script>

<style>

</style>
