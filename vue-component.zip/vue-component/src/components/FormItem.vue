<template>
 <div>
   <!-- 负责显示一些错误信息 -->
   <label v-if="label">{{label}}</label>
    <div>
      <slot></slot>
      <p v-if="validateStatus=='error'" class='error'>
        {{errorMessage}}
      </p>
    </div>
 </div>
</template>

<script>
export default{
  name:"kFormItem",
  // 可以获取form的实例
  inject:['form'],
  data(){
    return {
      validateStatus:'',
      errorMessage:''
    }
  },
  created(){
    this.$bus.$on('kFormItem',(value)=>{
      this.validate(value)
    })
    // this.getRules()
  },
  methods:{
    getRules(){
      let formRules = this.form.rules[this.prop]
      return formRules
    },
    
    // 校验
    validate(obj){
      if(obj.name !== this.prop){
        return 
      }
      const rule = this.getRules()
      const value = this.form.model[this.prop]
      console.log(rule,value)
      if(Arrary.isArray(value)){
        value.forEach(v=>{
          if(rule.required && !value){

          }
          if(rule.mixLength && value.length<rule.mixLength){
            
          }
        })
      }else{

      }
      if(rule.required && !value){
        this.errorMessage = rule.message
        this.validateStatus = 'error'
      }else{
        this.validateStatus = 'validating'
      }
    }
  },
  // watch:{
    
  // }
  // props:["label","props"],
  props:{
    label:{
      type:String,
    },
    prop:{
      type:String
    }
  }
  // 依赖注入
  // inject:["name"],
  // // props:['name'],
  // name:'formitem'
}
</script>

<style>
p.error{
  color:red;
}
</style>
